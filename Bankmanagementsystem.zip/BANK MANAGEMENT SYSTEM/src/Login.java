import java.sql.*;

import javax.swing.*;

import java.awt.*;
import java.awt.event.*;

public class Login extends JFrame implements ActionListener{
	
	JButton login, clear, signup; 
	JTextField cardTextField;
	JPasswordField pinTextField;
	
	Login(){
		
		setLayout(null);
		
		ImageIcon i1 = new ImageIcon(ClassLoader.getSystemResource("axis bank.png"));
		Image i2 = i1.getImage().getScaledInstance(100, 50, Image.SCALE_DEFAULT);
		ImageIcon i3 = new ImageIcon(i2);
		JLabel label = new JLabel(i3);	
		label.setBounds(5, -10, 150, 100);
		add(label);
		
		JLabel text = new JLabel("WELCOME TO AXIS BANK");
		text.setFont(new Font("Osward", Font.BOLD, 38));
		text.setBounds(175, -30, 600, 200);
		add(text);	
		
		JLabel cardno = new JLabel("CARD NUMBER");
		cardno.setFont(new Font("Calibri", Font.BOLD, 20));
		cardno.setBounds(20, 100, 400, 200);
		add(cardno);
		
		cardTextField = new JTextField();
		cardTextField.setBounds(250, 188, 250,30);
		cardTextField.setFont(new Font("Arial", Font.PLAIN, 14));
		add(cardTextField);
		
		JLabel pin = new JLabel("PIN");
		pin.setFont(new Font("Calibri", Font.BOLD, 20));
		pin.setBounds(20, 170, 400, 200);
		add(pin);
		
		pinTextField = new JPasswordField();
		pinTextField.setBounds(250, 259, 250,30);
		pinTextField.setFont(new Font("Arial", Font.BOLD, 14));
		add(pinTextField);
		
		login = new JButton("SIGN IN");
		login.setBackground(Color.gray);
		login.setForeground(Color.white);
		login.setBounds(300, 320, 100, 30);
		login.addActionListener(this);
		add(login);
		
		clear = new JButton("CLEAR");
		clear.setBackground(Color.gray);
		clear.setForeground(Color.white);
		clear.setBounds(420, 320, 100, 30);
		clear.addActionListener(this);
		add(clear);
		
		signup = new JButton("SIGN UP");
		signup.setBackground(Color.gray);
		signup.setForeground(Color.white);
		signup.setBounds(360, 370, 100, 30);
		signup.addActionListener(this);
		add(signup);
	
		
	
		
		getContentPane().setBackground(Color.white);
		setTitle("ATM");
		setSize(800, 480);
		setVisible(true);
		setLocation(250, 125);
	
	}
	public void actionPerformed(ActionEvent ae) {
		if (ae.getSource() == clear) {
			cardTextField.setText("");
			pinTextField.setText("");
		}
		else if (ae.getSource() == login) {
			Conn conn = new Conn();
			String cardnumber = cardTextField.getText();
			String pinnumber = pinTextField.getText();
			
			String q1 = "select * from login where cardnumber = '"+cardnumber+"' and PIN = '"+pinnumber+"'";
			
			try {
				ResultSet rs = conn.s.executeQuery(q1);
				
				if (rs.next()) {
					setVisible(false);
					new Transactions(pinnumber).setVisible(true);
				}
				else {
					JOptionPane.showMessageDialog(null, "Incorrect Card Number or PIN");
				}
				
			}
			catch(Exception e) {
				System.out.println(e);
			}
			
			
			
		}
		else if (ae.getSource() == signup) {
			
			setVisible(false);
			new Signupone().setVisible(true);
			
		}
	}

	public static void main(String[] args) {
		new Login();
		
		

	}

}
